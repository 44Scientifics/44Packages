from setuptools import find_packages, setup

setup(
    name="FortyFour",
    version="0.0.3",
    description="This package put together all the tools i have created",
    package_dir={"": "src"},
    packages=find_packages(where="src"),
    author="44 SCIENTIFICS LTD",
    author_email="44scientifics@gmail.com",
    url="https://github.com/44Scientifics/44Packages.git",
)
