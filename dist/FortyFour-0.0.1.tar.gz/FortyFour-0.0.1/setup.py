from setuptools import find_packages, setup


setup(
    name="FortyFour",
    version="0.0.1",
    description="This package put together all the tools i have created",
    package_dir={"":"src"},
    packages=find_packages(where="src")
)