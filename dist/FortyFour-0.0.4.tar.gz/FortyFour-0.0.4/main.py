from FortyFour.Finance.company import Company

comp = Company('AAPL')

print(comp.company_name)
